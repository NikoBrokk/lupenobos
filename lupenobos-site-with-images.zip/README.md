# Lupen OBOS – statisk nettside (Astro + Tailwind)

Dette repoet er klart for GitHub Pages. Du kan redigere innhold i `src/content/articles/` (MDX-filer).

## Rask start lokalt
1. Installer Node 20 (eller nyere) og npm.
2. Kjør: `npm install`
3. Kjør: `npm run dev` (åpner utviklerserver)
4. Bygg: `npm run build`

## Deploy på GitHub Pages
1. Lag et nytt GitHub-repo og last opp alle filene.
2. I GitHub: *Settings → Pages → Build and deployment → Source: GitHub Actions* (workflow ligger allerede i `.github/workflows/deploy.yml`).
3. Push til `main`. Actions bygger og publiserer automatisk.

## Eget domene (lupenobos.no)
- Legg inn A-records på domenet til GitHub Pages (IPv4): `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
- (Valgfritt IPv6 AAAA): `2606:50c0:8000::153`, `2606:50c0:8001::153`, `2606:50c0:8002::153`, `2606:50c0:8003::153`
- Sett `CNAME` i repoets Pages-innstillinger til `lupenobos.no` (filen `public/CNAME` er allerede inkludert).

## Struktur
- `src/pages/` – statiske sider (`/`, `/artikler`, `/talenter`, `/om`)
- `src/content/articles/` – artikler i MDX/Markdown
- `src/layouts/` og `src/components/` – designblokker
- `public/` – statiske filer (logo, CNAME, robots.txt)

## Skriv ny artikkel
Opprett en fil i `src/content/articles/` som `mitt-innlegg.mdx`:

```md
---
title: "Tittel"
excerpt: "Kort ingress"
date: 2025-08-08
tags: ["analyse", "talenter"]
author: "Ditt navn"
cover: "/path/til/bilde.jpg"
---

Brødtekst i Markdown. Du kan bruke **fet** skrift, lister osv.
```

## Videreutvikling
- Legg til grafer/heatmaps som bilder, eller koble på en enkel CMS senere (Netlify CMS / GitHub CMS).
- Juster farger i `tailwind.config.mjs`.
- Oppdater `site` i `astro.config.mjs` når domenet peker riktig.
